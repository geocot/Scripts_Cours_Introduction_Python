import zipfile
fichier = "creationfichiers.zip"
fichierZip = zipfile.ZipFile(fichier, 'w',
                             compression=zipfile.ZIP_DEFLATED,
                             compresslevel=-1)
fichierZip.write("fichierZip.py", arcname="test/fichierZip.py")
fichierZip.close()

