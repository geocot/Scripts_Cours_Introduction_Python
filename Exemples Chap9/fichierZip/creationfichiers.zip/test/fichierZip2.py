import zipfile
fichier = "creationfichiers.zip"
fichierZip = zipfile.ZipFile(fichier, 'a',
                             compression=zipfile.ZIP_DEFLATED,
                             compresslevel=-1)
#Ajout du fichier dans un répertoire test, on peut aussi changer le nom du fichier
fichierZip.write("fichierZip.py", arcname="test/fichierZip2.py")
fichierZip.close()



